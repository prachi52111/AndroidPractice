public class loop{
 

  public static void main(String[]args)
{

int n=6;
 for(int i=1; i<=n; ++i)
{
System.out.println("hello");
}
}
}