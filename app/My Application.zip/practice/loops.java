public class loops{

public static void main(String[]args)

{
int n=5,i=1;
do{


System.out.println(i);
i++;
}while(i<=n);


}
}